'use client'
import { FormEvent, useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, KeyRound, Loader2 } from 'lucide-react'
import { supabase } from '@/lib/supabase'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (event: FormEvent) => {
    event.preventDefault()
    setLoading(true)
    setError('')

    if (!supabase) {
      setError('Add Supabase credentials to enable login.')
      setLoading(false)
      return
    }

    const { data, error: signInError } = await supabase.auth.signInWithPassword({ email, password })
    if (signInError || !data.user) {
      setError(signInError?.message || 'Unable to sign in.')
      setLoading(false)
      return
    }

    const { data: profile } = await supabase.from('users').select('role').eq('id', data.user.id).maybeSingle()
    const role = profile?.role

    if (role === 'admin' || role === 'worker') window.location.href = role === 'worker' ? '/worker' : '/admin'
    else window.location.href = '/account'
  }

  return (
    <div className="mx-auto grid min-h-[calc(100vh-180px)] max-w-6xl items-center gap-14 px-6 py-16 lg:grid-cols-2 lg:px-10">
      <div>
        <Link href="/" className="flex items-center gap-2 text-xs uppercase tracking-[.2em] text-navy/50">
          <ArrowLeft size={14} /> Back home
        </Link>
        <p className="mt-16 text-xs font-semibold uppercase tracking-[.25em] text-gold">Portal access</p>
        <h1 className="mt-4 text-6xl leading-none">
          Your village,<br /><i className="font-normal text-gold">your voice.</i>
        </h1>
        <p className="mt-6 max-w-md leading-7 text-navy/55">
          Citizens and authorities sign in through the same secure gate — with role-based access to the right workspace.
        </p>
      </div>

      <div className="glass rounded-3xl p-7 shadow-luxury md:p-10">
        <div className="mb-8 flex h-12 w-12 items-center justify-center rounded-full bg-navy text-gold">
          <KeyRound size={21} />
        </div>
        <h2 className="text-3xl">Sign in</h2>
        <p className="mt-2 text-sm leading-6 text-navy/55">Use the email and password from your SafaiSetu account.</p>

        <form onSubmit={handleLogin} className="mt-8 space-y-5">
          <label className="block text-sm font-semibold">
            Email
            <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="mt-3 w-full rounded-xl border border-gold/30 bg-ivory p-4 outline-none focus:border-gold" />
          </label>
          <label className="block text-sm font-semibold">
            Password
            <input required type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="mt-3 w-full rounded-xl border border-gold/30 bg-ivory p-4 outline-none focus:border-gold" />
          </label>
          <button disabled={loading} className="flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-4 text-sm font-semibold uppercase tracking-[.15em] text-ivory disabled:opacity-60">
            {loading && <Loader2 size={16} className="animate-spin" />}Sign in
          </button>
        </form>

        {error && <p className="mt-5 text-sm text-red-700">{error}</p>}

        <p className="mt-8 text-sm text-navy/55">
          New to SafaiSetu?{' '}
          <Link href="/register" className="font-semibold text-gold">Create an account</Link>
        </p>
        <p className="mt-4 text-xs leading-5 text-navy/45">
          By continuing, you agree to use SafaiSetu responsibly and help keep community reports accurate.
        </p>
      </div>
    </div>
  )
}
