'use client'
import { FormEvent, useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, CheckCircle2, Loader2, ShieldCheck, User, Users2 } from 'lucide-react'
import { supabase } from '@/lib/supabase'

type Step = 'role' | 'email' | 'otp' | 'password' | 'done'
type Role = 'citizen' | 'authority'

const steps: Step[] = ['role', 'email', 'otp', 'password']

export default function RegisterPage() {
  const [step, setStep] = useState<Step>('role')
  const [role, setRole] = useState<Role | null>(null)
  const [email, setEmail] = useState('')
  const [otp, setOtp] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')

  const stepIndex = steps.indexOf(step)

  const chooseRole = (r: Role) => { setRole(r); setError('') }

  const goToEmail = () => {
    if (!role) { setError('Choose citizen or authority to continue.'); return }
    setError('')
    setStep('email')
  }

  const sendOtp = async (event: FormEvent) => {
    event.preventDefault()
    setLoading(true); setError(''); setMessage('')
    if (!supabase) { setError('Add Supabase credentials to enable registration.'); setLoading(false); return }
    const { error: otpError } = await supabase.auth.signInWithOtp({ email, options: { shouldCreateUser: true } })
    if (otpError) setError(otpError.message)
    else { setMessage(`A verification code has been sent to ${email}.`); setStep('otp') }
    setLoading(false)
  }

  const verifyOtp = async (event: FormEvent) => {
    event.preventDefault()
    setLoading(true); setError('')
    if (!supabase) { setLoading(false); return }
    const { error: verifyError } = await supabase.auth.verifyOtp({ email, token: otp, type: 'email' })
    if (verifyError) setError(verifyError.message)
    else setStep('password')
    setLoading(false)
  }

  const finishRegistration = async (event: FormEvent) => {
    event.preventDefault()
    setError('')
    if (password.length < 8) { setError('Password must be at least 8 characters.'); return }
    if (password !== confirm) { setError('Passwords do not match.'); return }
    setLoading(true)
    if (!supabase) { setLoading(false); return }

    const { data: updated, error: updateError } = await supabase.auth.updateUser({ password })
    if (updateError || !updated.user) { setError(updateError?.message || 'Unable to set password.'); setLoading(false); return }

    const { error: profileError } = await supabase
      .from('users')
      .upsert({ id: updated.user.id, role: role === 'authority' ? 'admin' : 'citizen' })
    if (profileError) { setError(profileError.message); setLoading(false); return }

    await supabase.auth.signOut()
    setStep('done')
    setLoading(false)
  }

  return (
    <div className="mx-auto grid min-h-[calc(100vh-180px)] max-w-6xl items-center gap-14 px-6 py-16 lg:grid-cols-2 lg:px-10">
      <div>
        <Link href="/login" className="flex items-center gap-2 text-xs uppercase tracking-[.2em] text-navy/50">
          <ArrowLeft size={14} /> Back to sign in
        </Link>
        <p className="mt-16 text-xs font-semibold uppercase tracking-[.25em] text-gold">Join SafaiSetu</p>
        <h1 className="mt-4 text-6xl leading-none">
          Report it,<br /><i className="font-normal text-gold">resolve it.</i>
        </h1>
        <p className="mt-6 max-w-md leading-7 text-navy/55">
          Create an account as a citizen to report civic issues, or as an authority to review and resolve them.
        </p>
      </div>

      <div className="glass rounded-3xl p-7 shadow-luxury md:p-10">
        {step !== 'done' && (
          <div className="mb-8 flex gap-2">
            {steps.map((s, i) => (
              <span key={s} className={`h-1 flex-1 rounded-full ${i <= stepIndex ? 'bg-gold' : 'bg-gold/20'}`} />
            ))}
          </div>
        )}

        {step === 'role' && (
          <>
            <h2 className="text-3xl">Who are you?</h2>
            <p className="mt-2 text-sm leading-6 text-navy/55">This decides which workspace you land in after signing in.</p>
            <div className="mt-8 grid grid-cols-2 gap-4">
              <button type="button" onClick={() => chooseRole('citizen')} className={`rounded-2xl border p-6 text-left transition ${role === 'citizen' ? 'border-gold bg-gold/10' : 'border-gold/25 bg-ivory'}`}>
                <User size={22} className="text-gold" />
                <p className="mt-4 text-sm font-semibold">Citizen</p>
                <p className="mt-1 text-xs text-navy/50">Report issues & track progress</p>
              </button>
              <button type="button" onClick={() => chooseRole('authority')} className={`rounded-2xl border p-6 text-left transition ${role === 'authority' ? 'border-gold bg-gold/10' : 'border-gold/25 bg-ivory'}`}>
                <Users2 size={22} className="text-gold" />
                <p className="mt-4 text-sm font-semibold">Authority</p>
                <p className="mt-1 text-xs text-navy/50">Review & resolve reports</p>
              </button>
            </div>
            {error && <p className="mt-5 text-sm text-red-700">{error}</p>}
            <button onClick={goToEmail} className="mt-8 flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-4 text-sm font-semibold uppercase tracking-[.15em] text-ivory">
              Continue
            </button>
          </>
        )}

        {step === 'email' && (
          <form onSubmit={sendOtp}>
            <h2 className="text-3xl">Enter your email</h2>
            <p className="mt-2 text-sm leading-6 text-navy/55">We will send a one-time verification code.</p>
            <label className="mt-8 block text-sm font-semibold">
              Email address
              <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="mt-3 w-full rounded-xl border border-gold/30 bg-ivory p-4 outline-none focus:border-gold" />
            </label>
            {error && <p className="mt-5 text-sm text-red-700">{error}</p>}
            <button disabled={loading} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-4 text-sm font-semibold uppercase tracking-[.15em] text-ivory disabled:opacity-60">
              {loading && <Loader2 size={16} className="animate-spin" />}Send OTP
            </button>
            <button type="button" onClick={() => setStep('role')} className="mt-4 w-full text-xs text-navy/50 underline">Change role</button>
          </form>
        )}

        {step === 'otp' && (
          <form onSubmit={verifyOtp}>
            <h2 className="text-3xl">Enter the code</h2>
            <p className="mt-2 text-sm leading-6 text-navy/55">We sent a six-digit code to {email}.</p>
            <label className="mt-8 block text-sm font-semibold">
              Verification code
              <input required inputMode="numeric" maxLength={6} value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, ''))} placeholder="000000" className="mt-3 w-full rounded-xl border border-gold/30 bg-ivory p-4 text-center text-xl tracking-[.5em] outline-none focus:border-gold" />
            </label>
            {message && <p className="mt-5 flex items-center gap-2 text-sm text-green-700"><CheckCircle2 size={16} />{message}</p>}
            {error && <p className="mt-5 text-sm text-red-700">{error}</p>}
            <button disabled={loading} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-4 text-sm font-semibold uppercase tracking-[.15em] text-ivory disabled:opacity-60">
              {loading && <Loader2 size={16} className="animate-spin" />}Verify OTP
            </button>
            <button type="button" onClick={() => setStep('email')} className="mt-4 w-full text-xs text-navy/50 underline">Use a different email</button>
          </form>
        )}

        {step === 'password' && (
          <form onSubmit={finishRegistration}>
            <div className="mb-8 flex h-12 w-12 items-center justify-center rounded-full bg-navy text-gold">
              <ShieldCheck size={21} />
            </div>
            <h2 className="text-3xl">Create a password</h2>
            <p className="mt-2 text-sm leading-6 text-navy/55">Last step — this secures your account for future sign-ins.</p>
            <label className="mt-8 block text-sm font-semibold">
              New password
              <input required type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" className="mt-3 w-full rounded-xl border border-gold/30 bg-ivory p-4 outline-none focus:border-gold" />
            </label>
            <label className="mt-5 block text-sm font-semibold">
              Confirm password
              <input required type="password" value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="Type it again" className="mt-3 w-full rounded-xl border border-gold/30 bg-ivory p-4 outline-none focus:border-gold" />
            </label>
            {error && <p className="mt-5 text-sm text-red-700">{error}</p>}
            <button disabled={loading} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-4 text-sm font-semibold uppercase tracking-[.15em] text-ivory disabled:opacity-60">
              {loading && <Loader2 size={16} className="animate-spin" />}Complete registration
            </button>
          </form>
        )}

        {step === 'done' && (
          <div className="text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-green-700 text-ivory">
              <CheckCircle2 size={26} />
            </div>
            <h2 className="mt-6 text-3xl">Registration complete</h2>
            <p className="mt-2 text-sm leading-6 text-navy/55">Your account is ready. Sign in to reach your dashboard.</p>
            <Link href="/login" className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-4 text-sm font-semibold uppercase tracking-[.15em] text-ivory">
              Go to sign in
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
